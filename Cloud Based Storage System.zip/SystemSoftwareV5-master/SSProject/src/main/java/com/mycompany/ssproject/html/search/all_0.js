var searchData=
[
  ['adminpanelcontroller_0',['AdminPanelController',['../classcom_1_1mycompany_1_1ssproject_1_1AdminPanelController.html',1,'com::mycompany::ssproject']]],
  ['app_1',['App',['../classcom_1_1mycompany_1_1ssproject_1_1App.html',1,'com::mycompany::ssproject']]]
];
